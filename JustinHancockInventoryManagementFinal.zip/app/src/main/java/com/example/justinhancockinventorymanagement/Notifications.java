package com.example.justinhancockinventorymanagement;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Notifications extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private TextView permissionStatus;
    private CheckBox lowInventoryCheckbox, overstockedCheckbox, locationChangesCheckbox;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // Initialize UI elements
        permissionStatus = findViewById(R.id.sms_permission_status);
        Button requestPermissionButton = findViewById(R.id.request_sms_permission_button);
        lowInventoryCheckbox = findViewById(R.id.low_inventory_notification);
        overstockedCheckbox = findViewById(R.id.upcoming_event_notification);
        locationChangesCheckbox = findViewById(R.id.goal_weight_notification);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("NotificationPrefs", MODE_PRIVATE);

        // Load saved preferences and set the initial state of checkboxes
        loadPreferences();

        // Initially set the permission status
        updatePermissionStatus();

        // Handle permission request button click
        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());

        // Handle checkbox state changes and save preferences
        lowInventoryCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> savePreference("LowInventory", isChecked));
        overstockedCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> savePreference("Overstocked", isChecked));
        locationChangesCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> savePreference("LocationChanges", isChecked));
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            permissionStatus.setText(R.string.permission_status_granted);
        } else {
            permissionStatus.setText(R.string.permission_status_not_granted);
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatus.setText(R.string.permission_status_granted);
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadPreferences() {
        lowInventoryCheckbox.setChecked(sharedPreferences.getBoolean("LowInventory", false));
        overstockedCheckbox.setChecked(sharedPreferences.getBoolean("Overstocked", false));
        locationChangesCheckbox.setChecked(sharedPreferences.getBoolean("LocationChanges", false));
    }

    private void savePreference(String key, boolean value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }
}