package com.example.justinhancockinventorymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final String TABLE_NAME = "users";
    private static final String TABLE_NAME_2 = "inventory";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "USERNAME";
    private static final String COL_3 = "EMAIL";
    private static final String COL_4 = "PASSWORD";
    private static final String COL_5 = "PHONE";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 6);
    }

    @Override
    public void onConfigure(SQLiteDatabase db){
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DatabaseHelper", "onCreate called");
        // Create users table
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT UNIQUE, EMAIL TEXT UNIQUE, PASSWORD TEXT, PHONE TEXT)");
        Log.d("DatabaseHelper", "Users table created");
        // Create inventory table
        db.execSQL("CREATE TABLE " + TABLE_NAME_2 + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, ITEM_NUMBER INTEGER, DESCRIPTION TEXT, LOCATION TEXT, QUANTITY INTEGER, FOREIGN KEY(USERNAME) REFERENCES users(USERNAME))");
        Log.d("DatabaseHelper", "Inventory table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_2);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert a new user
    public boolean insertUser(String username, String email, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, username);
        contentValues.put(COL_3, email);
        contentValues.put(COL_4, password);
        contentValues.put(COL_5, phone);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    // Check if a user exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE USERNAME=? AND PASSWORD=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Check if email or username is already taken
    public boolean checkIfUserExists(String username, String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE USERNAME=? OR EMAIL=?", new String[]{username, email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Check database for item number in same location
    public boolean isLocationExistsForItem(SQLiteDatabase db, int itemNumber, String location) {
        String[] columns = {"item_number"};
        String selection = "item_number = ? AND location = ?";
        String[] selectionArgs = {String.valueOf(itemNumber), location};

        Cursor cursor = db.query(
                TABLE_NAME_2,   // The table to query
                columns,       // The columns to return
                selection,     // The columns for the WHERE clause
                selectionArgs, // The values for the WHERE clause
                null,          // Don't group the rows
                null,          // Don't filter by row groups
                null           // The sort order
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Insert a new inventory item
    public boolean insertItem(int id, String username, String description, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("USERNAME", username);
        contentValues.put("ITEM_NUMBER", id);
        contentValues.put("DESCRIPTION", description);
        contentValues.put("LOCATION", location);
        contentValues.put("QUANTITY", quantity);

        // Log the values being inserted
        Log.d("DatabaseHelper", "Inserting item: Username: " + username + ", Item Number: " + id + ", Description: " + description + ", Location: " + location + ", Quantity: " + quantity);

        long result = db.insert(TABLE_NAME_2, null, contentValues);

        // Log the result of the insertion
        if (result != -1) {
            Log.d("DatabaseHelperTest", "Item inserted with ID: " + result);
        }
        else {
            Log.d("DatabaseHelperTest", "Item insertion failed");
        }
        return result != -1;
    }

    // Update an existing inventory item
    public boolean updateItem(int id, String description, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("DESCRIPTION", description);
        contentValues.put("LOCATION", location);
        contentValues.put("QUANTITY", quantity);
        int result = db.update(TABLE_NAME_2, contentValues, "ID=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Delete an inventory item
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME_2, "ID=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Retrieve all inventory items for a specific user
    public Cursor getItems(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Log the username & query
        Log.d("DatabaseHelperTest", "Fetching items for username: " + username);

        Cursor cursor = db.rawQuery("SELECT * FROM inventory WHERE USERNAME=?", new String[]{username});

        // Log the number of rows returned
        Log.d("DatabaseHelperTest", "Number of items found: " + cursor.getCount());

        return cursor;
    }

    public String getUserPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT PHONE FROM " + TABLE_NAME + " WHERE USERNAME=?", new String[]{username});
        if (cursor != null && cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow("PHONE"));
            cursor.close();
            return phoneNumber;
        }
        return null;
    }
}