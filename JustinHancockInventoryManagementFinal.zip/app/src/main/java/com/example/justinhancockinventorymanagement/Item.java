package com.example.justinhancockinventorymanagement;

public class Item {

    private int id;  // ID in the database
    private int itemNumber; // Number to show id in the database and on recyclerView adapter
    private String description;  // Description of the item
    private String location;  // Location of the item
    private int quantity;  // Quantity of the item

    // Constructor
    public Item(int id, int itemNumber, String description, String location, int quantity) {
        this.id = id;
        this.itemNumber = itemNumber;
        this.description = description;
        this.location = location;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
