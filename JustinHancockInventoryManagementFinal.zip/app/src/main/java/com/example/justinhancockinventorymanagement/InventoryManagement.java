package com.example.justinhancockinventorymanagement;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.content.Intent;
import android.widget.ImageView;
import android.Manifest;

import java.util.ArrayList;
import java.util.List;

public class InventoryManagement extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ItemAdapter itemAdapter;
    private int currentItemNumber = 1; // Start item numbers from 1
    String currentUsername;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_management);

        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button addItemButton = findViewById(R.id.addItemButton);
        ImageView notificationIcon = findViewById(R.id.notificationIcon);

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("NotificationPrefs", MODE_PRIVATE);

        // Retrieve username of current user
        currentUsername = getIntent().getStringExtra("USERNAME");

        // Load items from Database
        List<Item> itemList = loadItemsFromDatabase();

        // Log the size of the itemList
        Log.d("InventoryManagementTest", "Number of items loaded" + itemList.size());

        // Set up the RecyclerView
        itemAdapter = new ItemAdapter(this, itemList, this);
        recyclerView.setAdapter(itemAdapter);

        // Log that the adapter has been set
        Log.d("InventoryManagementTest", "Adapter has been set to RecyclerView");

        // Handle the notification icon click
        notificationIcon.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryManagement.this, Notifications.class);
            startActivity(intent);
        });

        // Handle Add Item button click
        addItemButton.setOnClickListener(v -> showAddItemDialog());
    }

    private List<Item> loadItemsFromDatabase() {
        List<Item> items = new ArrayList<>();

        // Log to confirm the method is being called
        Log.d("InventoryManagementTest", "Loading items from database to user: " + currentUsername);

        Cursor cursor = dbHelper.getItems(currentUsername);

        // Log to check if the cursor has any rows
        if (cursor != null) {
            Log.d("InventoryManagementTest", "Cursor count: " + cursor.getCount());
        }
        else {
            Log.d("InventoryManagementTest", "Cursor is null");
        }

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("ID"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("DESCRIPTION"));
                String location = cursor.getString(cursor.getColumnIndexOrThrow("LOCATION"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("QUANTITY"));

                Item item = new Item(id, id, description, location, quantity);
                items.add(item);
                Log.d("InventoryManagementTest", "Loaded item:" + item.toString());
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        EditText descriptionInput = dialogView.findViewById(R.id.descriptionInput);
        EditText locationInput = dialogView.findViewById(R.id.locationInput);
        EditText quantityInput = dialogView.findViewById(R.id.quantityInput);
        CheckBox holdItemCheckbox = dialogView.findViewById(R.id.holdItemCheckbox);
        Button addButton = dialogView.findViewById(R.id.addButton);

        AlertDialog dialog = builder.create();

        addButton.setOnClickListener(v -> {
            String description = descriptionInput.getText().toString().trim();
            String location = locationInput.getText().toString().trim();
            String quantityStr = quantityInput.getText().toString().trim();

            // Log the button click and input values
            Log.d("InventoryManagement", "Add Button Clicked");
            Log.d("InventoryManagement", "Description: " + description + ", Location: " + location + ", Quantity: " + quantityStr);

            if (TextUtils.isEmpty(description) || description.length() > 30) {
                Toast.makeText(InventoryManagement.this, "Invalid description. Max 30 characters.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (TextUtils.isEmpty(location) || location.length() > 20) {
                Toast.makeText(InventoryManagement.this, "Invalid location. Max 20 characters.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (TextUtils.isEmpty(quantityStr) || !TextUtils.isDigitsOnly(quantityStr)) {
                Toast.makeText(InventoryManagement.this, "Invalid quantity.", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityStr);

            // Insert the item into the database
            Log.d("InventoryManagement", "Attempting to insert item");
            if (insertItem(currentItemNumber, description, location, quantity)) {
                Log.d("InventoryManagement", "Item inserted successfully");

                // Create new item object and call checkAndSendNotification function
                Item newItem = new Item(currentItemNumber, currentItemNumber, description, location, quantity);
                checkAndSendNotification(newItem);

                Toast.makeText(InventoryManagement.this, "Item added successfully.", Toast.LENGTH_SHORT).show();
                if (!holdItemCheckbox.isChecked()) {
                    currentItemNumber++;
                    descriptionInput.setText("");
                }
                locationInput.setText("");
                quantityInput.setText("");
                if (!holdItemCheckbox.isChecked()) {
                    dialog.dismiss();
                }
                // Refresh the list of items and update the RecyclerView
                List<Item> updatedItemList = loadItemsFromDatabase();
                itemAdapter.updateItemList(updatedItemList);
                itemAdapter.notifyDataSetChanged();
            } else {
                Log.d("InventoryManagement", "Failed to insert item");
                Toast.makeText(InventoryManagement.this, "Failed to add item. Location already exists for this item number.", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private boolean insertItem(int id, String description, String location, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Check if the location already exists for this item number
        if (dbHelper.isLocationExistsForItem(db, id, location)) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("USERNAME", currentUsername);
        values.put("ITEM_NUMBER", id);
        values.put("description", description);
        values.put("location", location);
        values.put("quantity", quantity);

        long newRowId = db.insert("inventory", null, values);
        return newRowId != -1;
    }

    void checkAndSendNotification(Item item) {
        // Check if permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {

            // Retrieve preferences
            boolean notifyLowInventory = sharedPreferences.getBoolean("LowInventory", false);
            boolean notifyOverstocked = sharedPreferences.getBoolean("Overstocked", false);
            boolean notifyLocationChange = sharedPreferences.getBoolean("LocationChanges", false);

            // Get the current user phone number
            String phoneNumber = dbHelper.getUserPhoneNumber(currentUsername);

            if (phoneNumber == null) {
                Log.d("InventoryManagementTest", "Phone number not found for user: " + currentUsername);
                return;
            }

            // Low inventory notification
            if (notifyLowInventory && item.getQuantity() < 3) {
                sendSmsNotification(phoneNumber, "Low Inventory Alert: " + item.getDescription() + " is low with only " + item.getQuantity() + " left in stock.");
            }

            // Overstocked notification
            if (notifyOverstocked && item.getQuantity() > 6) {
                sendSmsNotification(phoneNumber,"Overstock Alert: " + item.getDescription() + " is overstocked with " + item.getQuantity() + " units.");
            }

            // Location change notification (trigger this when location changes in your existing logic)
            if (notifyLocationChange) {
                sendSmsNotification(phoneNumber, "Location Change Alert: " + item.getDescription() + " has been changed to " + item.getLocation() + ".");
            }
        }
        else {
            Log.d("InventoryManagementTest", "SMS permission not granted");
        }
    }

    // Example SMS sending method
    private void sendSmsNotification(String phone, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phone, null, message, null, null);
        Log.d("InventoryManagementTest", "SMS sent to " + phone + " with message: " + message);
    }
}