package com.example.justinhancockinventorymanagement;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private final Context context;
    private final List<Item> itemList;
    private final InventoryManagement inventoryManagement;

    public ItemAdapter(Context context, List<Item> itemList, InventoryManagement inventoryManagement) {
        this.context = context;
        this.itemList = itemList;
        this.inventoryManagement = inventoryManagement;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = itemList.get(position);

        // Log the data being bound
        Log.d("ItemAdapterTest", "Binding item at position " + position + ": " + item.toString());

        holder.itemNumber.setText(String.valueOf(item.getItemNumber()));
        holder.itemDescription.setText(item.getDescription());
        holder.itemLocation.setText(item.getLocation());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Log the actual values being set to the views
        Log.d("ItemAdapterTest", "Item Description: " + item.getDescription());
        Log.d("ItemAdapterTest", "Item Location: " + item.getLocation());
        Log.d("ItemAdapterTest", "Item Quantity: " + item.getQuantity());

        // Handle edit button click
        holder.editButton.setOnClickListener(v -> {
            // Open the edit dialog and prepopulate it with the item's data
            showEditDialog(item);
        });

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> {
            // Open the confirmation dialog
            showDeleteConfirmationDialog(item, position);
        });
    }

    @Override
    public int getItemCount() {
        // Log the number of items in the adapter
        Log.d("ItemAdapterTest", "Item count: " + itemList.size());
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView itemNumber, itemDescription, itemLocation, itemQuantity;
        ImageButton editButton, deleteButton;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNumber = itemView.findViewById(R.id.itemNumber);
            itemDescription = itemView.findViewById(R.id.itemDescription);
            itemLocation = itemView.findViewById(R.id.itemLocation);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    private void showEditDialog(Item item) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);

        EditText itemDescription = dialogView.findViewById(R.id.descriptionInput);
        EditText itemLocation = dialogView.findViewById(R.id.locationInput);
        EditText itemQuantity = dialogView.findViewById(R.id.quantityInput);

        itemDescription.setText(item.getDescription());
        itemLocation.setText(item.getLocation());
        itemQuantity.setText(String.valueOf(item.getQuantity()));

        new AlertDialog.Builder(context)
                .setTitle("Edit Item")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    // Update the item in the database
                    DatabaseHelper dbHelper = new DatabaseHelper(context);
                    boolean updated = dbHelper.updateItem(item.getId(), itemDescription.getText().toString(), itemLocation.getText().toString(), Integer.parseInt(itemQuantity.getText().toString()));

                    if (updated) {
                        // Update the item in the list and notify the adapter
                        item.setDescription(itemDescription.getText().toString());
                        item.setLocation(itemLocation.getText().toString());
                        item.setQuantity(Integer.parseInt(itemQuantity.getText().toString()));
                        notifyItemChanged(itemList.indexOf(item));

                        inventoryManagement.checkAndSendNotification(item);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showDeleteConfirmationDialog(Item item, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete this item?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                    // Delete the item from the database
                    DatabaseHelper dbHelper = new DatabaseHelper(context);
                    boolean deleted = dbHelper.deleteItem(item.getId());

                    if (deleted) {
                        // Remove the item from the list and notify the adapter
                        itemList.remove(position);
                        notifyItemRemoved(position);
                    }
                })
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    public void updateItemList(List<Item> newList) {
        itemList.clear();
        itemList.addAll(newList);

        // Log the size of the new list
        Log.d("ItemAdapterTest", "Adapter updated with " + newList.size() + "items.");

        notifyDataSetChanged();
    }
}
